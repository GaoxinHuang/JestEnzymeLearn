# udemy-react-testing-projects
Code for projects presented in Udemy "React Testing with Jest and Enzyme" course

## Project READMEs
See individual project READMEs (in their directories) for more information. 

  * [Click Counter](https://github.com/flyrightsister/udemy-react-testing-projects/blob/master/click-counter/README.md)
  * [Jotto](https://github.com/flyrightsister/udemy-react-testing-projects/blob/master/jotto/README.md)
  * [Random Word Server](https://github.com/flyrightsister/udemy-react-testing-projects/blob/master/random-word-server/README.md)