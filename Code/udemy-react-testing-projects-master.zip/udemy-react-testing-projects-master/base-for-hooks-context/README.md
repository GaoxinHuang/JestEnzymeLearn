# Base project for Testing React Hooks / Context

This is a base project for starting at the Hooks / Context sections of [React Testing with Jest and Enzyme](https://www.udemy.com/course/react-testing-with-jest-and-enzyme/?referralCode=3A42BF689E28CADB0587)