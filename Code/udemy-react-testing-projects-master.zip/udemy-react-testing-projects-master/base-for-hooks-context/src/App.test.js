import React from 'react';
import App from './App';

test('future test goes here', () => {
  // just a placeholder test so that jest won't complain about
  // test-less test file
});
